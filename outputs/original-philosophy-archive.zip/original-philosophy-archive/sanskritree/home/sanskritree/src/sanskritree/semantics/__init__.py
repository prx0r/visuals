"""Typed semantic intermediate representation."""
